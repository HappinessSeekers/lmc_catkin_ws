#!/usr/bin/env python
# coding=utf-8
import rospy
import numpy as np
import math
from std_msgs.msg import Float32


class Env(object):
    def __init__(self):
        # observation setting
        self.BLDC1_state = np.zeros(10, dtype=np.float)
        self.BLDC2_state = np.zeros(10, dtype=np.float)
        self.BLDC1_current = 0.0
        self.BLDC2_current = 0.0
        self.reset_limit = 5.0
        self.s_bound = 400.0
        self.s_bound2 = self.s_bound ** 2
        self.current_bound = 20.0
        self.BLDC1_current = 0.0
        self.BLDC1_v = 0.0
        self.BLDC2_v = 0.0
        # ros setting
        rospy.init_node('ddpg_track')
        self.BLDC1_current_pub = rospy.Publisher('BLDC1_current', Float32, queue_size=100)
        self.BLDC2_current_pub = rospy.Publisher('BLDC2_current', Float32, queue_size=100)
        rospy.Subscriber('BLDC1_v', Float32, self.BLDC1_vCallback)
        rospy.Subscriber('BLDC2_v', Float32, self.BLDC2_vCallback)
        rospy.Subscriber("BLDC1_S", Float32, self.BLDC1_SCallback)
        rospy.Subscriber("BLDC2_S", Float32, self.BLDC2_SCallback)
        self.rate = rospy.Rate(50)
        
    def BLDC1_SCallback(self, data):
        BLDC1_state = np.append(self.BLDC1_state, data.data)
        self.BLDC1_state = BLDC1_state[-10:]

    def BLDC2_SCallback(self, data):
        BLDC2_state = np.append(self.BLDC2_state, data.data)
        self.BLDC2_state = BLDC2_state[-10:]

    def BLDC1_vCallback(self, data):
        self.BLDC1_v = data.data

    def BLDC2_vCallback(self, data):
        self.BLDC2_v = data.data  

    def step(self, BLDC1_current):
        done = False
        observation = None
        BLDC1_d_current = BLDC1_current[0] - self.BLDC1_current
        self.BLDC1_current = BLDC1_current
        self.BLDC2_current = self.BLDC2_current + np.random.normal(0, 1)
        if self.BLDC2_current > 20:
            self.BLDC2_current = 20
        elif self.BLDC2_current < -20:
            self.BLDC2_current = -20
        self.pub_data()
        if not rospy.is_shutdown():
            self.rate.sleep()
            if self.BLDC1_state[-1] > self.s_bound or self.BLDC1_state[-1] < -self.s_bound:
                done = True
            elif self.BLDC2_state[-1] > self.s_bound or self.BLDC2_state[-1] < -self.s_bound:
                done = True
            reward = self.caculate_reward(BLDC1_d_current)
            observation = np.concatenate([self.BLDC1_state, self.BLDC2_state])
            observation = np.append(observation,self.BLDC1_v)
            observation = np.append(observation,self.BLDC2_v)
            observation = np.append(observation,self.BLDC1_current)
        return observation, reward, done

    def pub_data(self):
        self.BLDC1_current_pub.publish(self.BLDC1_current)
        self.BLDC2_current_pub.publish(self.BLDC2_current)

    def caculate_reward(self,d_current):
        reward = -math.fabs(self.BLDC1_state[-1] - self.BLDC2_state[-1])/10 - math.fabs(self.BLDC1_v-self.BLDC2_v)/50 - math.fabs(d_current)/20
        return reward

    def reset(self):
        done = False
        while (not rospy.is_shutdown()) and (done is not True):
            self.rate.sleep()
            if -self.reset_limit < self.BLDC1_state[-1] < self.reset_limit and -self.reset_limit < self.BLDC2_state[-1] <self.reset_limit:
                done = True
            self.caculate_reset_current()
            self.pub_data()
        observation = np.concatenate([self.BLDC1_state, self.BLDC2_state])
        observation = np.append(observation,self.BLDC1_v)
        observation = np.append(observation,self.BLDC2_v)
        observation = np.append(observation,self.BLDC1_current)
        return observation

    def caculate_reset_current(self):
        KP = 1
        BLDC1_current = - KP * self.BLDC1_state[-1]
        BLDC2_current = - KP * self.BLDC2_state[-1]
        self.BLDC1_current = np.clip(BLDC1_current,-self.current_bound,self.current_bound)
        self.BLDC2_current = np.clip(BLDC2_current,-self.current_bound,self.current_bound)







