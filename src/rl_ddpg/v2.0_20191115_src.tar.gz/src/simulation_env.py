#!/usr/bin/env python
'''simulation_env ROS Node'''
# license removed for brevity
import rospy
import numpy as np
import math
from std_msgs.msg import Float32


class BLDC:
    def __init__(self):
        self.s = 0.0
        self.v = 0.0
        self.current = 0.0
        self.ratio = 0.02
        self.friction_a0 = 1
        self.friction_a1 = 0.05
        self.currentMax = 20.0

    def set_current(self, current):
        if -self.currentMax < current < self.currentMax:
            self.current = current
        elif current >= self.currentMax:
            self.current = self.currentMax
        elif current <= -self.currentMax:
            self.current = -self.currentMax

    def step(self, time):
        self.s = self.s + self.v * time * 0.5
        if self.v > 0:
            current_real = self.current-self.v*self.friction_a1 - self.friction_a0
        elif self.v < 0:
            current_real = self.current-self.v*self.friction_a1 + self.friction_a0
        elif self.v == 0:
            if -self.friction_a0 < self.current < self.friction_a0:
                current_real = 0
            elif self.current >= self.friction_a0:
                current_real = self.current - self.friction_a0
            else:
                current_real = self.current + self.friction_a0
        self.v = self.v + current_real/self.ratio * time
        self.s = self.s + self.v * time * 0.5

    def s_measure(self):
        return self.s + np.random.uniform(0,0.5)
   
    def v_measure(self):
        return self.v + np.random.uniform(0,5)

class sin_cruve:
    def __init__(self,bound=200,period=5):
        self.bound = bound
        self.period = period
        self.t = 0.0
        self.s = 0.0
        self.v = 0.0 
    def cal_s(self):
        self.s = self.bound * math.sin(2 * math.pi *self.t / self.period)
    def cal_v(self):
        self.v = (self.bound * math.sin(2 * math.pi *self.t / self.period) - self.bound * math.sin(2 * math.pi *(self.t - 0.002) / self.period))/0.002
    def step(self,t):
        self.t = self.t + t
        self.cal_s()
        self.cal_v()

    def s_measure(self):
        return self.s + np.random.uniform(0,0.5)

    def v_measure(self):
        return self.v + np.random.uniform(0,5)

    def set_current(self, current):
        pass 

class step_cruve:
    def __init__(self,bound=[-200,200],ramp=400,a=1000,period=10):
        self.bound_low = bound[0]
        self.bound_high = bound[1]
        self.s = 0.0
        self.v = 0.0
        self.a = a
        self.ramp = ramp
        self.period = period
        self.t_period = 0.0
        self.t = 0.0
    def step(self, t):
        self.t = self.t + t
        self.t_period =  math.fmod(self.t,self.period)
        self.cal_v(t)
        self.cal_s(t)
    def cal_v(self,t):
        if (self.s < self.bound_high - self.ramp**2/2/self.a) and  (self.t_period < self.period / 2) :
            self.v = min(self.v + t * self.a,self.ramp)
        elif (self.s > self.bound_high - self.ramp**2/2/self.a) and  (self.t_period < self.period / 2) and self.v > 0:
            self.v =  self.v - t * self.a  
        elif  (self.s > self.bound_low + self.ramp**2/2/self.a) and  (self.t_period > self.period / 2):
            self.v = max(self.v - t * self.a,-self.ramp)
        elif (self.s < self.bound_low + self.ramp**2/2/self.a) and  (self.t_period > self.period / 2) and self.v < 0:
            self.v =  self.v + t * self.a  
        else:
            self.v = 0

    def cal_s(self,t):
        self.s = self.s + t*self.v

    def s_measure(self):
        return self.s + np.random.uniform(0,0.5)

    def v_measure(self):
        return self.v + np.random.uniform(0,5)

    def set_current(self, current):
        pass 


BLDC1 = BLDC()
BLDC2 = step_cruve(bound=[-300,300],ramp=200,a=400,period=20)


def BLDC1_currentCallback(data):
    global BLDC1
    BLDC1.set_current(data.data)


def BLDC2_currentCallback(data):
    global BLDC2
    BLDC2.set_current(data.data)


def main():
    rospy.init_node('simulation_env', anonymous=True)
    rate = rospy.Rate(500)
    count = 0
    count_max = 5
    global BLDC1
    global BLDC2
    BLDC1_S_pub = rospy.Publisher('BLDC1_S', Float32, queue_size=100)
    BLDC2_S_pub = rospy.Publisher('BLDC2_S', Float32, queue_size=100)

    BLDC1_v_pub = rospy.Publisher('BLDC1_v', Float32, queue_size=100)
    BLDC2_v_pub = rospy.Publisher('BLDC2_v', Float32, queue_size=100)

    BLDC_ds_pub = rospy.Publisher('BLDC_ds', Float32, queue_size=100)
    BLDC_dv_pub = rospy.Publisher('BLDC_dv', Float32, queue_size=100)

    rospy.Subscriber("BLDC1_current", Float32, BLDC1_currentCallback)
    rospy.Subscriber("BLDC2_current", Float32, BLDC2_currentCallback)
    while not rospy.is_shutdown():
        count = count + 1
        if count >= count_max:
            count = 0
            # for sample data 
            # BLDC1_S_pub.publish(BLDC1.s_measure())
            # BLDC2_S_pub.publish(BLDC2.s_measure())
            # BLDC1_v_pub.publish(BLDC1.v_measure())
            # BLDC2_v_pub.publish(BLDC2.v_measure())
            ## for real data 
            BLDC1_S_pub.publish(BLDC1.s)
            BLDC2_S_pub.publish(BLDC2.s)
            BLDC1_v_pub.publish(BLDC1.v)
            BLDC2_v_pub.publish(BLDC2.v)

            ds = BLDC1.s - BLDC2.s
            dv = BLDC1.v - BLDC2.v
            BLDC_ds_pub.publish(ds)
            BLDC_dv_pub.publish(dv)
            print("BLDC1_S: "+str(BLDC1.s))
            print("BLDC1_V: "+str(BLDC1.v))
            print("BLDC1_C: "+str(BLDC1.current))
            print("BLDC2_S: "+str(BLDC2.s))
            print("BLDC2_V: "+str(BLDC2.v))
            # print("BLDC2_C: "+str(BLDC2.current))
        BLDC1.step(0.002)
        BLDC2.step(0.002)
        rate.sleep()


if __name__ == '__main__':
    main()
